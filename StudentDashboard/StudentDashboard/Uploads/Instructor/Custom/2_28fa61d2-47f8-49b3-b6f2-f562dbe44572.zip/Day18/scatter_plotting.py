from plot_util import *
x=np.linspace(1,10,100)
plt.scatter(x,np.sin(x),c=x,s=100*np.sin(x),alpha=0.3)
plt.show()