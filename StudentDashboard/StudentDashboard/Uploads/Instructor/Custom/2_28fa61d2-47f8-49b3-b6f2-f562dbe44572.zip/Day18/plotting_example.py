import matplotlib.pyplot as plt
# plt.plot([1,2,3,4])
plt.plot([1,2,3,4],[6,9,2,3])
plt.xlabel("Date")
plt.ylabel("Publications")
plt.title("Publication vs Date plot")
plt.savefig("publication vs date plot")
plt.savefig("publication vs date plot.jpeg")
plt.show()