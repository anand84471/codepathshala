import numpy as np
import matplotlib.pyplot as plt
x=np.linspace(1,10,100)
plt.plot(x,np.sin(x),"--g")
plt.plot(x,np.cos(x),"k^",markersize=10)
plt.show()