import openpyxl
path=r"cancer_data.xlsx"
wb=openpyxl.load_workbook(path)
sheet1=wb["cancer data"]

#reading first 10 rows from column 1

for i in range(1,10):
    print(sheet1.cell(i,1).value)
    
for i in range(71,80):
    print(sheet1.cell(i,4).value)
    

for i in range(71,81):
    print(sheet1.cell(i,2).value,"\t", sheet1.cell(i,3).value,"\t", sheet1.cell(i,4).value)