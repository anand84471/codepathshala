from Bio.Blast import NCBIWWW
path=r"sample_blast_file.fasta"
fasta_file=open(path)
handler=NCBIWWW.qblast("blastn","nt",fasta_file)
print( handler.read())